#!/usr/bin/env node
// 萌卡 NT 3.0 IPC 插件：加速助手
// 通过标准输入输出与框架通信（native-ipc-v1）
import { createRequire } from 'module'
import fs from 'fs'
import path from 'path'
import readline from 'readline'
import crypto from 'crypto'
import { execSync } from 'child_process'

const __dirname = path.dirname(new URL(import.meta.url).pathname)
const VERSION = '3.0.0'
const PLUGIN_ID = 'accel-assistant'

// ===== 运行状态 =====
let ready = false
let reqId = 0
const pending = new Map()
const LOG_BUFFER = []

// ===== 账号状态 =====
const bots = new Set()
const protoOnline = new Map() // self_id -> Set(protocol_id)
const BOT_STATE = new Map()
const BOT_CFG = new Map()
const accelLockQueue = []
let accelLockRunning = false

// ===== 配置默认值 =====
const DEFAULT_BOT = { client_type: 'android', autoReaddEnabled: true, readdManualOff: false, lastReaddTime: 0 }
const BOTS_DIR = path.join(__dirname, 'data', 'bots')
const BOTS_DIR_PARENT = path.join(__dirname, 'data')
try { fs.mkdirSync(BOTS_DIR, { recursive: true }) } catch {}

function botFile(k) { return path.join(BOTS_DIR, `${k}.json`) }
function B(self_id) {
  const k = String(self_id)
  if (BOT_CFG.has(k)) return BOT_CFG.get(k)
  let saved = null
  try { saved = JSON.parse(fs.readFileSync(botFile(k), 'utf8')) } catch {}
  const cfg = { ...JSON.parse(JSON.stringify(DEFAULT_BOT)), ...(saved || {}) }
  BOT_CFG.set(k, cfg)
  if (!saved) saveBot(k)
  return cfg
}
function saveBot(k) {
  const c = BOT_CFG.get(String(k)); if (!c) return
  fs.writeFileSync(botFile(k), JSON.stringify(c, null, 2))
}
function S(self_id) {
  const k = String(self_id)
  if (!BOT_STATE.has(k)) BOT_STATE.set(k, { accelAutoConfigured: false, accelCatchUpDone: false })
  return BOT_STATE.get(k)
}

// ===== 协议/设备配置缓存 =====
let PROTOCOL_LIST = []
let DEVICE_PROFILE_LIST = []

async function loadProtocolList() {
  try {
    const r = await call('get_protocol_list', {}, 10000)
    const list = Array.isArray(r) ? r : (r?.data || [])
    PROTOCOL_LIST = list.map(p => ({
      ...p,
      platform: typeof p.platform === 'string' ? p.platform.toLowerCase() : p.platform,
      type: typeof p.type === 'string' ? p.type.toLowerCase() : p.type
    }))
    log(`协议列表加载: ${PROTOCOL_LIST.length} 个`)
  } catch (e) { log('加载协议列表失败: ' + e.message) }
}

async function loadDeviceProfileList() {
  try {
    const r = await call('get_device_profile_list', {}, 10000)
    DEVICE_PROFILE_LIST = Array.isArray(r) ? r : (r?.data || [])
    log(`设备配置列表加载: ${DEVICE_PROFILE_LIST.length} 个`)
  } catch (e) { log('加载设备配置失败: ' + e.message) }
}

function protocolById(id) { return PROTOCOL_LIST.find(p => p.id === id) }
function protocolPlatform(id) { return protocolById(id)?.platform || '' }
function isAndroidProtocolId(id) { return protocolPlatform(id) === 'android' }
function isLinuxProtocolId(id) { return protocolPlatform(id) === 'linux' }
function enabledProtocols(filter) { return PROTOCOL_LIST.filter(p => p.state !== false && (!filter || filter(p))) }
function resolveProtocolId(intent) {
  if (Number.isInteger(intent)) return intent
  const platform = intent === 'linuxqq' ? 'linux' : 'android'
  return enabledProtocols(p => p.platform === platform)[0]?.id ?? null
}
function firstDeviceProfileId() { return DEVICE_PROFILE_LIST.find(d => d.id > 0)?.id || null }

function isOnline(self_id) { return protoOnline.get(String(self_id))?.size > 0 }
function androidOnline(id) { return [...(protoOnline.get(String(id)) || [])].some(pid => isAndroidProtocolId(pid)) }
function linuxOnline(id) { return [...(protoOnline.get(String(id)) || [])].some(pid => isLinuxProtocolId(pid)) }
function setProto(self_id, protocol_id, online) {
  const k = String(self_id)
  if (!protoOnline.has(k)) protoOnline.set(k, new Set())
  const set = protoOnline.get(k)
  if (protocol_id != null) online ? set.add(protocol_id) : set.delete(protocol_id)
  if (set.size) { bots.add(Number(self_id)); log(`在线账号: ${k}`) } else { bots.delete(Number(self_id)); log(`账号离线: ${k}`) }
}

// ===== IPC 输出 =====
function sendFrame(obj) {
  process.stdout.write(JSON.stringify(obj) + '\n')
}
function log(s) {
  const ts = new Date().toLocaleTimeString('zh-CN', { hour12: false })
  LOG_BUFFER.push({ ts, text: String(s).slice(0, 500) })
  if (LOG_BUFFER.length > 200) LOG_BUFFER.splice(0, LOG_BUFFER.length - 200)
  console.error(`[${ts}] ${s}`)
}
const sleep = ms => new Promise(r => setTimeout(r, ms))

// ===== action 调用 =====
function call(action, params = {}, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    if (!ready) { reject(new Error('框架未就绪')); return }
    const id = String(++reqId)
    pending.set(id, { resolve, reject, action })
    let p = { ...params }
    if (p.client_type != null && p.protocol_id == null) {
      p.protocol_id = resolveProtocolId(p.client_type)
      delete p.client_type
    }
    if (p.self_id != null && p.protocol_id == null) {
      p.protocol_id = resolveProtocolId(B(String(p.self_id))?.client_type || 'android')
    }
    sendFrame({ type: 'action', id, action, params: p })
    setTimeout(() => { if (pending.has(id)) { pending.delete(id); reject(new Error(action + ' 超时')) } }, timeoutMs)
  })
}

// ===== 锁 =====
async function accelLock(fn) {
  return new Promise((resolve, reject) => {
    accelLockQueue.push(async () => { try { const r = await fn(); resolve(r) } catch (e) { reject(e) } })
    runAccelLock()
  })
}
async function runAccelLock() {
  if (accelLockRunning) return
  accelLockRunning = true
  while (accelLockQueue.length) { const fn = accelLockQueue.shift(); await fn() }
  accelLockRunning = false
}

// ===== 加速任务 =====
async function ensureBot(self_id) {
  const k = String(self_id)
  const bc = B(k); const st = S(k)
  if (bc.autoReaddEnabled === false || bc.readdManualOff) return
  const due = !st.accelCheckedAt || Date.now() - st.accelCheckedAt > 5 * 60 * 1000
  if (due && androidOnline(Number(k))) {
    ensureAccelConfigured(Number(k)).catch(e => log(`[${k}] 加速配置核验失败: ${e.message}`))
  }
  if (!st.accelCatchUpDone) {
    st.accelCatchUpDone = true
    setTimeout(() => catchUpAccelTasks(Number(k)).catch(e => log(`[${k}] 补挂加速失败: ${e.message}`)), 6000)
  }
}

async function ensureAccelConfigured(self_id) {
  const st = S(String(self_id))
  st.accelCheckedAt = Date.now()
  if (st.accelConfigInFlight) return
  st.accelConfigInFlight = true
  try {
    await accelLock(async () => {
      const ct = B(String(self_id))?.client_type || 'android'
      if (ct !== 'android') return
      const protocol_id = resolveProtocolId('android')
      if (protocol_id == null) throw new Error('无可用安卓协议')
      const s = await call('level_task_management', { self_id: Number(self_id), protocol_id, operation: 'status' }, 20000)
      const settings = s?.settings || {}
      const enabled = settings.schedule_enabled === true
      const tasks = settings.selected_tasks || []
      if (enabled && Array.isArray(tasks) && tasks.length) { st.accelAutoConfigured = true; return }
      log(`[${self_id}] 加速调度缺失，重新开启...`)
      const lt = await call('get_level_tasks', { self_id: Number(self_id), protocol_id }, 20000)
      if (lt?.skipped) { log(`[${self_id}] 等级任务跳过: ${lt.reason}`); return }
      const allTasks = [...(lt?.base_info?.base_task_list || []), ...(lt?.extra_info?.extra_task_list || [])]
      const selected = allTasks.filter(t => t && t.title && (t.available !== false || t.can_execute)).map(t => t.title)
      if (!selected.length) return
      await call('level_task_management', {
        self_id: Number(self_id), protocol_id, operation: 'settings',
        tasks: selected, schedule_enabled: true, schedule_time: '00:30'
      }, 20000)
      log(`[${self_id}] 自动开启加速：${selected.length} 个任务，00:30 执行`)
      st.accelAutoConfigured = true
    })
  } finally { st.accelConfigInFlight = false }
}

async function catchUpAccelTasks(self_id) {
  return accelLock(async () => {
    const ct = B(String(self_id))?.client_type || 'android'
    const protocol_id = resolveProtocolId(ct)
    if (protocol_id == null) throw new Error('无可用协议')
    const lt = await call('get_level_tasks', { self_id: Number(self_id), protocol_id }, 20000)
    if (lt?.skipped) { log(`[${self_id}] 补挂跳过: ${lt.reason}`); return }
    const allTasks = [...(lt?.base_info?.base_task_list || []), ...(lt?.extra_info?.extra_task_list || [])]
    const todo = allTasks.filter(t => t && t.title && !t.is_done && (t.available !== false || t.can_execute)).map(t => t.title)
    if (!todo.length) return
    log(`[${self_id}] 补挂加速：${todo.length} 个任务`)
    await call('execute_level_tasks', { self_id: Number(self_id), protocol_id, tasks: todo }, 90000)
    log(`[${self_id}] 补挂完成`)
  })
}

// ===== 重登 =====
async function autoReaddIfPossible(self_id, forceType = null) {
  const k = String(self_id)
  const bc = B(k)
  if (bc.autoReaddEnabled === false || bc.readdManualOff) { log(`[${k}] 自动重登已关闭`); return }
  if (bc.lastReaddTime && Date.now() - bc.lastReaddTime < 60000) return
  const target = forceType || resolveTargetProto(self_id)
  const r = await offlineDeleteReadd(Number(self_id), target)
  log(`[${k}] 自动重登结果: ${r.msg || r.error || JSON.stringify(r)}`)
}

function resolveTargetProto(self_id) {
  const bc = B(String(self_id))
  return bc.client_type === 'linuxqq' ? 'linuxqq' : 'android'
}

async function offlineDeleteReadd(self_id, clientType) {
  const k = String(self_id)
  let pwd = null
  try { pwd = getFrameworkPassword(self_id) } catch {}
  if (!pwd) return { ok: false, error: '无可用密码' }

  let existingProto = null
  try {
    const r0 = await call('get_bot_list', {}, 10000)
    const botList0 = Array.isArray(r0) ? r0 : (r0?.data || [])
    const existingBot = botList0.find(b => Number(b.self_id) === self_id && b.protocol && (
      (clientType === 'linuxqq' && isLinuxProtocolId(b.protocol.id)) ||
      (clientType !== 'linuxqq' && isAndroidProtocolId(b.protocol.id))
    ))
    existingProto = existingBot?.protocol?.id ?? null
  } catch {}

  let protoIdTry = existingProto
  let protoNameStr = ''
  if (clientType === 'linuxqq') {
    protoIdTry = resolveLinuxProtocolId()
    protoNameStr = 'Linux'
  } else {
    const candidates = resolveAndroidProtocolIds(protoIdTry)
    protoIdTry = candidates[0] ?? null
    protoNameStr = '安卓'
  }
  if (protoIdTry == null) return { ok: false, error: `无可用${protoNameStr}协议` }

  const deviceProfileId = firstDeviceProfileId()
  if (deviceProfileId == null) return { ok: false, error: '无可用设备配置' }

  try {
    const r = await call('get_bot_list', {}, 10000)
    const botList = Array.isArray(r) ? r : (r?.data || [])
    const existing = botList.find(b => Number(b.self_id) === self_id && b.protocol && (
      (clientType === 'linuxqq' && isLinuxProtocolId(b.protocol.id)) ||
      (clientType !== 'linuxqq' && isAndroidProtocolId(b.protocol.id))
    ))
    if (existing && existing.protocol?.id != null) {
      const pid = existing.protocol.id
      try { await call('offline_account', { self_id, protocol_id: pid }, 15000) } catch {}
      await sleep(2000)
      try {
        const r2 = await call('get_bot_list', {}, 10000)
        const bl2 = Array.isArray(r2) ? r2 : (r2?.data || [])
        if (bl2.find(b => Number(b.self_id) === self_id && b.protocol?.id === pid)) {
          try { await call('delete_account', { self_id, protocol_id: pid }, 15000) } catch {}
        }
      } catch {}
      await sleep(1000)
    }
  } catch {}

  try {
    await call('add_account', { self_id, password: pwd, protocol_id: protoIdTry, device_profile_id: deviceProfileId }, 30000)
    const loginR = await call('login_account', { self_id, protocol_id: protoIdTry }, 30000)
    if (loginR?.need_verify) return { ok: false, verify: true, msg: '需要验证', loginR }
    B(k).lastReaddTime = Date.now(); saveBot(k)
    return { ok: true, msg: `重新登录成功(${protoNameStr})`, protocol_id: protoIdTry }
  } catch (e) {
    return { ok: false, error: e.message || String(e) }
  }
}

function resolveAndroidProtocolIds(currentProtocolId = null) {
  const androids = enabledProtocols(p => p.platform === 'android')
  const list = androids.filter(p => p.version?.includes('9.3.75'))
  let ordered = [...list]
  if (currentProtocolId != null) {
    const cur = ordered.find(p => p.id === currentProtocolId)
    if (cur) ordered = [cur, ...ordered.filter(p => p.id !== currentProtocolId)]
  }
  return ordered.map(p => p.id)
}
function resolveLinuxProtocolId() { return enabledProtocols(p => p.platform === 'linux')[0]?.id ?? null }

function getFrameworkPassword(self_id) {
  try {
    const db = path.join(BOTS_DIR_PARENT, '..', '..', 'data', 'config.db')
    const sql = `SELECT password FROM accounts WHERE self_id = ${Number(self_id)} LIMIT 1;`
    const v = execSync(`sqlite3 "${db}" "${sql}"`, { timeout: 3000, encoding: 'utf-8' }).trim()
    return v || null
  } catch { return null }
}

// ===== 电脑登录 =====
async function linuxQuickLogin(self_id, executeTask = false) {
  const androidPid = resolveProtocolId('android')
  const linuxPid = resolveLinuxProtocolId()
  if (androidPid == null) throw new Error('无可用安卓协议')
  if (linuxPid == null) throw new Error('无可用 Linux 协议')

  const r = await call('get_bot_list', {}, 10000)
  const lb = (Array.isArray(r) ? r : (r?.data || [])).find(b => Number(b.self_id) === self_id && b.protocol && isLinuxProtocolId(b.protocol.id))
  if (lb && lb.status === 1) return { ok: true, msg: '电脑QQ当前在线中' }

  const cc = await call('check_cache', { self_id, protocol_id: linuxPid }, 10000)
  if (cc?.has_cache) {
    await call('cache_login', { self_id, protocol_id: linuxPid }, 30000)
  } else {
    const qr = await call('get_login_qr', { protocol_id: linuxPid }, 10000)
    if (!qr?.url) throw new Error('获取 Linux 登录二维码失败')
    const k = qr.url
    await call('scan_qr', { self_id, protocol_id: androidPid, k }, 30000)
    await call('auth_qr', { self_id, protocol_id: androidPid, k, skip_phone_confirm: true }, 30000)
  }
  const loginR = await call('login_account', { self_id, protocol_id: linuxPid }, 30000)
  if (executeTask) {
    await call('execute_level_tasks', { self_id, protocol_id: linuxPid, tasks: ['电脑QQ在线'] }, 60000).catch(e => log(`[${self_id}] 电脑在线任务执行失败: ${e.message}`))
  }
  return { ok: true, msg: '电脑QQ登录成功', loginR }
}

// ===== 消息事件 =====
const recentSent = new Map()
function isDup(self_id, text) {
  const key = `${self_id}:${text}`
  const now = Date.now()
  if (recentSent.has(key) && now - recentSent.get(key) < 5000) return true
  recentSent.set(key, now)
  return false
}

function onEvent(ev) {
  const evProtocolId = ev.protocol_id
  if (ev.self_id && ev.post_type !== 'bot_offline') ensureBot(ev.self_id).catch(() => {})
  switch (ev.post_type) {
    case 'bot_offline':
      if (ev.self_id) {
        if (evProtocolId != null) setProto(ev.self_id, evProtocolId, false)
        const sid = String(ev.self_id)
        const reason = ev.offline_reason
        log(`[掉线] ${sid} protocol_id=${evProtocolId} reason=${reason || 'unknown'}`)
        if (protocolPlatform(evProtocolId) === 'android' && reason !== 'active') {
          setTimeout(() => autoReaddIfPossible(sid, 'android').catch(() => {}), 8000)
        }
      }
      return
    case 'bot_online':
      if (ev.self_id && evProtocolId != null) setProto(ev.self_id, evProtocolId, true)
      return
    case 'friend_message':
    case 'group_message':
      handleMessage(ev)
      return
  }
}

function handleMessage(ev) {
  const self_id = Number(ev.self_id)
  if (!self_id) return
  const evProtocolId = ev.protocol_id
  const evPlatform = protocolPlatform(evProtocolId)
  const isLinux = evPlatform === 'linux'
  if (isLinux && androidOnline(self_id)) return
  ev._protocolId = evProtocolId || resolveProtocolId('android')
  const sender = ev.user_id || ev.sender?.user_id || 0
  if (Number(sender) !== self_id) return
  const text = extractText(ev.message)
  if (!text) return
  const sentTime = recentSent.get(self_id + ':' + text)
  if (sentTime && Date.now() - sentTime < 15000) return
  log(`[消息] self_id=${self_id} text="${text.slice(0,30)}"`)
  if (isDup(self_id, text)) return

  const reply = (txt) => sendFriendMsg(self_id, ev._protocolId, self_id, txt)
  const needBot = async (fn) => { if (!isOnline(self_id)) return; try { await fn() } catch(e) { log('[指令处理] ' + e.message) } }

  if (/^(加速菜单|菜单)$/.test(text)) {
    return reply('━━ 任务菜单 ━━\n== 查询加速\n== 电脑登录\n== 开启重登\n== 关闭重登\n== 重登状态\n━━━━━━━━')
  }
  if (/^查询加速$/.test(text)) return needBot(async () => {
    const pid = resolveProtocolId('android')
    const lt = await call('get_level_tasks', { self_id, protocol_id: pid }, 15000)
    const msg = await buildAccelStatusMsg(lt)
    reply(msg)
  })
  if (/^(电脑登录|登录电脑)$/.test(text)) return needBot(async () => {
    if (ev._protocolId && isLinuxProtocolId(ev._protocolId)) return
    const lr = await call('get_bot_list', {}, 10000)
    const lb = (Array.isArray(lr) ? lr : (lr?.data || [])).find(b => Number(b.self_id) === self_id && b.protocol && isLinuxProtocolId(b.protocol.id))
    if (lb && lb.status === 1) return reply('🖥️ 电脑QQ当前在线中')
    try {
      const r = await linuxQuickLogin(self_id, true)
      reply(r.ok ? `🖥️ ${r.msg}` : `❌ ${r.msg || r.error}`)
    } catch (e) { reply('❌ 电脑登录失败：' + e.message) }
  })
  if (/^开启重登$/.test(text)) return needBot(async () => {
    const bc = B(String(self_id))
    bc.autoReaddEnabled = true; bc.readdManualOff = false; saveBot(String(self_id))
    reply('🔄 自动重登已开启')
  })
  if (/^关闭重登$/.test(text)) return needBot(async () => {
    const bc = B(String(self_id))
    bc.autoReaddEnabled = false; bc.readdManualOff = true; saveBot(String(self_id))
    reply('🔄 自动重登已关闭')
  })
  if (/^重登状态$/.test(text)) return needBot(async () => {
    const bc = B(String(self_id))
    const enabled = bc.autoReaddEnabled !== false && !bc.readdManualOff
    const stateText = enabled ? '✅ 已开启' : (bc.readdManualOff ? '⛔ 手动关闭' : '⏸️ 验证暂停')
    const last = bc.lastReaddTime ? new Date(bc.lastReaddTime).toLocaleString('zh-CN') : '从未'
    reply(`🔄 自动重登：${stateText}\n⏰ 上次重登：${last}`)
  })
}

function sendFriendMsg(self_id, protocol_id, user_id, text) {
  if (protocol_id == null) return
  recentSent.set(`${self_id}:${text}`, Date.now())
  return call('send_friend_msg', {
    self_id: Number(self_id), protocol_id, user_id: Number(user_id),
    message: [{ type: 'text', data: { text } }]
  }, 30000).catch(() => {})
}

function extractText(msg) {
  if (typeof msg === 'string') return msg
  if (!Array.isArray(msg)) return ''
  return msg.filter(m => m?.type === 'text').map(m => m?.data?.text || '').join('').trim()
}

async function buildAccelStatusMsg(lt) {
  if (!lt || lt.error) return '❌ 获取加速信息失败'
  const base = lt.base_info || {}
  const extra = lt.extra_info || {}
  const lv = lt.level_info || {}
  const lines = []
  lines.push(`当前等级：${lv.level || '-'}`)
  lines.push(`升级天数：${lv.upgrade_days || '-'}`)
  lines.push('>>>>>>>>>>>>')
  lines.push(`基础加速：${(base.base_accelerate || 0)}`)
  lines.push(`付费加速：${(base.pay_accelerate || 0)}`)
  lines.push(`额外加速：${(extra.extra_accelerate || 0)}`)
  lines.push(`今日加速：${(lt.today_accelerate || 0)}`)
  lines.push('>>>>>>>>>>>>')
  const tasks = [...(base.base_task_list || []), ...(extra.extra_task_list || [])]
  const TASK_NAMES = {
    '电脑QQ在线': '电脑在线', '手机QQ在线': '手机在线', 'QQ连续登录': '连续登录',
    '加一位好友': '添加好友', '发布一条空间说说': '发布说说', '去日签卡打一次卡': '日签打卡',
    '去看免费小说': '阅读小说', '每日登录QQ经典农场': '经典农场', '去QQ会员福利社领福利券': '领福利券',
    '完成视频任务获得加速时长': '视频任务', '体验任一款小游戏15s': '体验游戏', '浏览十条空间好友动态': '浏览动态',
    '听歌领金币兑换加速': '金币兑换', '参与盲盒签并成功发布至空间': '盲盒签到', '创建小游戏擂台并取得成绩': '创建擂台',
    '看10秒漫剧': '观看漫剧', '去元宝提问1次': '元宝任务'
  }
  for (const t of tasks) {
    if (!t || !t.title) continue
    const name = TASK_NAMES[t.title] || t.title
    const done = t.is_done ? '[√]' : '[X]'
    lines.push(`${name}：${done}`)
  }
  lines.push('>>>>>>>>>>>>')
  return lines.join('\n')
}

// ===== 刷新账号列表 =====
async function refreshBots() {
  let known = new Set()
  try { for (const f of fs.readdirSync(BOTS_DIR)) { const m = f.match(/^(\d+)\.json$/); if (m) known.add(m[1]) } } catch {}
  for (const id of known) { try { B(id) } catch {} }
  let botList = []
  try {
    const r = await call('get_bot_list', {}, 10000)
    botList = Array.isArray(r) ? r : (r?.data || [])
    for (const b of botList) { if (b?.self_id != null) known.add(String(b.self_id)) }
  } catch(e) { log('[刷新] get_bot_list 失败: ' + e.message) }
  for (const id of known) protoOnline.set(String(id), new Set())
  for (const b of botList) {
    if (b?.self_id == null || !b.protocol) continue
    const pid = b.protocol.id
    if (b.status === 1 && b.online !== false && pid != null) protoOnline.get(String(b.self_id))?.add(pid)
  }
  for (const id of known) {
    if (protoOnline.get(id)?.size) {
      bots.add(Number(id))
      ensureBot(Number(id)).catch(() => {})
    }
  }
}

// ===== IPC 输入处理 =====
function handleFrame(m) {
  if (m.type === 'ready') {
    ready = true
    log('框架已就绪')
    Promise.all([loadProtocolList(), loadDeviceProfileList()])
      .then(() => refreshBots()).catch(() => {})
    return
  }
  if (m.type === 'action_result') {
    const p = pending.get(m.id)
    if (p) {
      pending.delete(m.id)
      if (m.ok) p.resolve(m.data !== undefined ? m.data : m)
      else p.reject(new Error(m.error || 'action 失败'))
    }
    return
  }
  if (m.type === 'event' || m.post_type) {
    onEvent(m.type === 'event' ? m.data : m).catch(e => log('事件处理异常: ' + e.message))
  }
}

// ===== 启动 =====
process.stdin.setEncoding('utf8')
const rl = readline.createInterface({ input: process.stdin, terminal: false })
rl.on('line', line => {
  if (!line.trim()) return
  try { handleFrame(JSON.parse(line)) } catch (e) { log('帧解析失败: ' + e.message) }
})
rl.on('close', () => { log('IPC 通道关闭，退出'); process.exit(0) })

sendFrame({ type: 'hello', api_version: '1', framework_api: '3.0.0', plugin_id: PLUGIN_ID, version: VERSION })
log('IPC 插件已启动，等待框架 ready')

// ===== 周期任务 =====
setInterval(() => {
  if (!ready) return
  refreshBots().catch(e => log(`[周期对账] 失败: ${e.message}`))
}, 3 * 60 * 1000)
